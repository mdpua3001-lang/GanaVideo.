plugins { id("com.android.application") }

android {
    namespace = "com.ganavideo.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.ganavideo.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-demo"
    }
}
