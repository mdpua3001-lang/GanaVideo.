package com.ganavideo.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int green = Color.rgb(13,107,73);
    private final int dark = Color.rgb(24,42,34);
    private final int muted = Color.rgb(104,121,112);
    private final int pale = Color.rgb(239,248,242);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(green);
        getWindow().setNavigationBarColor(Color.rgb(245,248,246));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(22), dp(22), dp(30));
        page.setBackgroundColor(Color.rgb(245,248,246));
        scroll.addView(page);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("▶", 22, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(green, 15));
        top.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(12),0,0,0);
        brand.addView(text("GanaVideo",22,dark,true));
        brand.addView(text("Tu espacio de recompensas",12,muted,false));
        top.addView(brand, new LinearLayout.LayoutParams(0,-2,1));
        TextView demo = text("DEMO",11,green,true); demo.setPadding(dp(12),dp(7),dp(12),dp(7)); demo.setBackground(round(Color.rgb(222,242,229),30));
        top.addView(demo);
        page.addView(top);

        TextView welcome = text("¡Hola!",27,dark,true); welcome.setPadding(0,dp(28),0,dp(4)); page.addView(welcome);
        page.addView(text("Este es tu panel de recompensas.",14,muted,false));

        LinearLayout balance = new LinearLayout(this); balance.setOrientation(LinearLayout.VERTICAL); balance.setPadding(dp(20),dp(20),dp(20),dp(20)); balance.setBackground(round(green,22));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(24); page.addView(balance,bp);
        balance.addView(text("SALDO DE DEMOSTRACIÓN",11,Color.rgb(211,239,221),true));
        balance.addView(text("$ 0 COP",34,Color.WHITE,true));
        TextView note = text("No representa dinero real ni es retirable.",12,Color.rgb(218,239,225),false); note.setPadding(0,dp(5),0,0); balance.addView(note);

        page.addView(sectionTitle("Gana recompensas"));
        LinearLayout ad = card();
        TextView icon = text("▶",20,green,true); icon.setGravity(Gravity.CENTER); icon.setBackground(round(pale,14)); ad.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout adText = new LinearLayout(this); adText.setOrientation(LinearLayout.VERTICAL); adText.setPadding(dp(13),0,0,0);
        adText.addView(text("Videos patrocinados",16,dark,true));
        TextView pending = text("Proveedor publicitario pendiente de aprobación",12,muted,false); pending.setPadding(0,dp(4),0,0); adText.addView(pending);
        ad.addView(adText,new LinearLayout.LayoutParams(0,-2,1)); page.addView(ad);
        Button watch = new Button(this); watch.setText("Los videos aún no están disponibles"); watch.setAllCaps(false); watch.setEnabled(false); watch.setTextColor(Color.rgb(112,126,117)); watch.setBackground(round(Color.rgb(224,231,226),14));
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-1,dp(52)); wp.topMargin=dp(12); page.addView(watch,wp);

        page.addView(sectionTitle("Tu actividad"));
        LinearLayout history=card(); history.setOrientation(LinearLayout.VERTICAL);
        history.addView(text("Todavía no tienes actividad",15,dark,true));
        TextView histNote=text("Cuando se habilite un proveedor autorizado, aquí aparecerán tus videos completados y recompensas verificadas.",13,muted,false); histNote.setPadding(0,dp(7),0,0); history.addView(histNote); page.addView(history);

        page.addView(sectionTitle("Información importante"));
        LinearLayout info=card(); info.setOrientation(LinearLayout.VERTICAL);
        info.addView(text("Esta versión es una demostración.",15,dark,true));
        TextView infoBody=text("No solicita datos bancarios, no muestra anuncios reales y no procesa retiros. Los pagos en efectivo solo se habilitarán después de contratar un proveedor que autorice expresamente recompensas monetarias en Colombia.",13,muted,false); infoBody.setPadding(0,dp(7),0,0); info.addView(infoBody); page.addView(info);

        TextView footer=text("GanaVideo · Versión de prueba 0.1.0",11,muted,false); footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(25),0,0); page.addView(footer);
        setContentView(scroll);
    }

    private TextView sectionTitle(String s){ TextView t=text(s,18,dark,true); t.setPadding(0,dp(25),0,dp(12)); return t; }
    private LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL); l.setPadding(dp(16),dp(16),dp(16),dp(16)); l.setBackground(round(Color.WHITE,18)); return l; }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private GradientDrawable round(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
