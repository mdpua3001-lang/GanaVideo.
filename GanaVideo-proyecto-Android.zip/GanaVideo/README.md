# GanaVideo — proyecto Android de demostración

Este proyecto contiene una primera interfaz nativa Android para GanaVideo.

## Estado de esta versión
- Aplicación Android nativa con pantalla principal.
- Saldo marcado explícitamente como demostración.
- Sección de videos deshabilitada mientras no exista un proveedor publicitario aprobado.
- Sin anuncios reales, cuentas, base de datos, retiros ni pagos.
- No recopila datos personales.

**No publicar esta versión como una app que paga dinero.** No acredita ganancias ni permite retiros. Antes de lanzar una versión comercial se debe contratar un proveedor que autorice por escrito el pago de recompensas monetarias por video completado en apps Android y confirme disponibilidad para Colombia; después se debe implementar su SDK, validación del lado del servidor, prevención de fraude, cuentas, saldo y pagos.

## Cómo generar un APK
1. Instala Android Studio en un computador.
2. Abre Android Studio y elige **Open**; selecciona la carpeta `GanaVideo` descomprimida.
3. Instala Android SDK Platform 36 cuando Android Studio lo solicite.
4. Espera a que termine la sincronización de Gradle.
5. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio generará un APK de depuración para pruebas. Para Google Play se debe generar un Android App Bundle (AAB) firmado desde **Build > Generate Signed Bundle / APK**.

## Identificador
`com.ganavideo.app`

Antes de publicar, cambia el identificador si lo necesitas y configura una clave de firma propia. No compartas esa clave ni su contraseña.
